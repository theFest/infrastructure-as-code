# Terraform module for Azure Key Vault configuration

This module configures a Azure Key Vault instance with Terraform.

## Resources

[Terraform Azure Key Vault reference](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault)
