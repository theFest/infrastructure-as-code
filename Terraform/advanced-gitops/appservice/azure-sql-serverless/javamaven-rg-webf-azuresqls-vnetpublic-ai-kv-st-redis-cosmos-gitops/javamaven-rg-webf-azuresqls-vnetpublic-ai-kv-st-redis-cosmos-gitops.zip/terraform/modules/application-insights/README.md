# Terraform module for Azure Application Insights configuration

This module configures an Azure Application Insights instance with Terraform.

## Resources

[What is Azure Application Insights](https://aka.ms/nubesgen-app-insights)
[Terraform Azure Application Insights reference](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_insights)
