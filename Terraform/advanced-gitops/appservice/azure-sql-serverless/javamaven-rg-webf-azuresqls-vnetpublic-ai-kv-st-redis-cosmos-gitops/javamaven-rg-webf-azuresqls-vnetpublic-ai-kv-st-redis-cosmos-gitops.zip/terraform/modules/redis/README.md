# Terraform module for Redis configuration

This module configures Azure Cache for Redis with Terraform.
