# Terraform module for Cosmos DB with MongoDB configuration

This module configures Cosmos DB with MongoDB with Terraform.
