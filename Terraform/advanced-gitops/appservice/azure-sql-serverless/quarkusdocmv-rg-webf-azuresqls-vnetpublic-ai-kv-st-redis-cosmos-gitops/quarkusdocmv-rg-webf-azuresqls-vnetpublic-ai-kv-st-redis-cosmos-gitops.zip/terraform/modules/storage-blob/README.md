# Terraform module for Blob storage configuration

This module configures a Blob storage with Terraform.
