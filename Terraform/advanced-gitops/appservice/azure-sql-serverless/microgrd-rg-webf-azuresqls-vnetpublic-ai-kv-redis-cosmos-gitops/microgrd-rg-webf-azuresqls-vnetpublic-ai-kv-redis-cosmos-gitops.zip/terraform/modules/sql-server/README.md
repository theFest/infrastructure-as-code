# Terraform module for SQL Server database configuration

This module configures a SQL Server database with Terraform.

## Resources

- [Azure SQL pricing](https://aka.ms/nubesgen-azure-sql-pricing)
- [SKU list for Azure SQL database](https://aka.ms/nubesgen-azure-sql-sku)
- [Terraform Azure SQL reference](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_database)
